////////////////////
/// C++ Object-oriented Programming
/// Adventure Game 6
/// Reference answer 
/// anssi.grohn@pkamk.fi
////////////////////
#ifndef __globals_h__
#define __globals_h__
enum Direction { North, South, East, West, kNumDirs };
#endif
