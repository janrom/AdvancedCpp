Give this command at command line to compile all codes, make Game.exe and attach all DLL-files to the Game.exe

g++ -o Game.exe *.h *.cpp -ID:\Omat_jutut\Opiskelu\AMK\AdvancedC++\TheGame\Engine -LD:\Omat_jutut\Opiskelu\AMK\AdvancedC++\TheGame\Engine -lCommand -lICommand -lCommandFactory -lIRenderer -lTextRenderer -lUpdateable
